
const muilter = require('multer');

const cloud = require('cloudinary');

const { CloudinaryStorage } = require('multer-storage-cloudinary');


function uploadimage() {

    cloud.config({

        cloudname: process.env.CLOUD_NAME,
        api_key: process.env.CLOUDINARY_API_KEY,
        api_secret_key: process.env.CLOUDINARY_SECRET_API_KEY


    });

    const multerStorage = new CloudinaryStorage({

        cloudinary: cloud,
        params: {
            folder: "UserImg",
            allowed_formats: ['png', 'jpg']
        }

    });


    const svresponse = muilter({ storage: multerStorage });

    return svresponse;


}

module.exports = { uploadimage }