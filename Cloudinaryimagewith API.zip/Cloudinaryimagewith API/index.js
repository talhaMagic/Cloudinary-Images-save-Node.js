 

const express = require("express");

const app = express();

const dotenv = require("dotenv").config();

app.set("view engine","ejs");

app.use(express.urlencoded({extended:true}));

const {uploadimage} = require('./Middlewere/Uploadimage');

const {Registerpage,Regsiterusercreate} = require('./Controllers/UserController');

const Upluploadimg = uploadimage();

app.route("/Register").get(Registerpage).post(Upluploadimg.single("userimage"),Regsiterusercreate);

app.listen(process.env.PORT,function(){

    console.log(`start server PORT ${process.env.PORT}`)

});


