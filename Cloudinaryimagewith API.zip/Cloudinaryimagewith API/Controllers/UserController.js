const bcrypt = require('bcrypt');

// @GET METHOD
// API to render the Signup page
function Registerpage(req, res) {
    return res.status(200).render("Signup"); // 200 status for rendering a page
}

// @POST METHOD
// API to create a new user
async function Registerusercreate(req, res) {
    try {
        const { username, useremail, userpass } = req.body;

        // Regular expressions for validation
        const usernamechekar = /^[a-zA-Z0-9_]{3,16}$/;
        const useremailchekar = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

        // Check if the username is valid
        if (!usernamechekar.test(username)) {
            return res.status(400).send({ "error": "Username is not valid, please try again" });
        }

        // Check if the email is valid
        if (!useremailchekar.test(useremail)) {
            return res.status(400).send({ "error": "User email is not valid, please try again" });
        }

        
        const hashpassword = await bcrypt.hash(userpass, 10);

        
        const userprofile = req.file.path;

        
        const newuser = {
            userName: username,
            userEmail: useremail,
            userPassword: hashpassword,
            UserImage: userprofile
        };

        
        const apiresponse = await fetch("https://6730903466e42ceaf160a69f.mockapi.io/Imageusersdata", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(newuser),
        });

        
        if (apiresponse.ok) {
            return res.status(201).send("API success");
        } else {
            return res.status(apiresponse.status).send({ "error": "API did not respond" });
        }
        
    } catch (error) {
        console.log(error); 
        return res.status(500).send({ "error": "Internal Server Error" });
    }
}

module.exports = { Registerpage, Registerusercreate };
